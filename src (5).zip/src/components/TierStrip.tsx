import { Link } from "@tanstack/react-router";
import {
  GAMEMODES,
  MODERN_GAMEMODES,
  GAMEMODE_ICON,
  MODERN_GAMEMODE_ICON,
  TIER_COLOR,
  type GamemodeSlug,
  type Tier,
} from "@/lib/gamemodes";
import type { PvpMode } from "@/hooks/usePvpMode";

interface Props {
  tiers: Partial<Record<GamemodeSlug, Tier>>;
  mode?: PvpMode;
}

export function TierStrip({ tiers, mode = "classic" }: Props) {
  const list = mode === "modern" ? MODERN_GAMEMODES : GAMEMODES;
  const icons: Record<string, string> =
    mode === "modern" ? MODERN_GAMEMODE_ICON : GAMEMODE_ICON;
  return (
    <div className="flex flex-wrap items-start justify-center gap-2">
      {list.map((g) => {
        const t = tiers[g.slug as GamemodeSlug];
        const ranked = Boolean(t);
        const inner = (
          <div
            className={`flex flex-col items-center gap-1 ${ranked ? "" : "opacity-30"}`}
            title={g.name}
          >
            <div
              className="flex h-9 w-9 items-center justify-center rounded-full border bg-card transition-all duration-300 ease-out hover:scale-125 hover:-translate-y-0.5"
              style={
                ranked
                  ? {
                      borderColor: TIER_COLOR[t!],
                      boxShadow: `0 0 10px -2px ${TIER_COLOR[t!]}`,
                    }
                  : { borderColor: "var(--border)" }
              }
            >
              <img
                src={icons[g.slug]}
                alt={g.name}
                className="pixel-icon h-6 w-6 object-contain transition-transform duration-300 ease-out"
              />
            </div>
            <div
              className="text-center text-[10px] font-black tabular-nums leading-none"
              style={{ color: ranked ? TIER_COLOR[t!] : undefined }}
            >
              {t ?? "—"}
            </div>
          </div>
        );
        return ranked ? (
          <Link
            key={g.slug}
            to="/tier/$gamemode"
            params={{ gamemode: g.slug }}
            onClick={(e) => e.stopPropagation()}
          >
            {inner}
          </Link>
        ) : (
          <div key={g.slug}>{inner}</div>
        );
      })}
    </div>
  );
}

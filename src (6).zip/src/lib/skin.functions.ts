import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const uuidSchema = z.object({
  name: z.string(),
});

type UuidResponse = { uuid: string | null };

const cache = new Map<string, { uuid: string | null; ts: number }>();
const CACHE_TTL_MS = 1000 * 60 * 60; // 1 hour

/**
 * Resolve a Minecraft Java username to a UUID (undashed).
 * We use UUIDs for renders because username → skin lookups are commonly rate-limited.
 */
export const resolveMinecraftUuid = createServerFn({ method: "GET" })
  .inputValidator((data) => uuidSchema.parse(data))
  .handler(async ({ data }): Promise<UuidResponse> => {
    const clean = data.name.trim().replace(/[^A-Za-z0-9_]/g, "");
    if (!clean) return { uuid: null };

    const key = clean.toLowerCase();
    const cached = cache.get(key);
    if (cached && Date.now() - cached.ts < CACHE_TTL_MS) return { uuid: cached.uuid };

    try {
      const res = await fetch(
        `https://api.mojang.com/users/profiles/minecraft/${encodeURIComponent(clean)}`,
        {
          headers: { "user-agent": "forgifiedtiers/skin-resolver" },
        },
      );

      if (!res.ok) {
        const out = { uuid: null };
        cache.set(key, { ...out, ts: Date.now() });
        return out;
      }

      const json = (await res.json()) as { id?: string };
      const uuid = typeof json.id === "string" && json.id.length >= 32 ? json.id : null;
      const out = { uuid };
      cache.set(key, { ...out, ts: Date.now() });
      return out;
    } catch {
      const out = { uuid: null };
      cache.set(key, { ...out, ts: Date.now() });
      return out;
    }
  });


alter table public.tiertagger_mods
  add column if not exists id uuid default gen_random_uuid(),
  add column if not exists version_label text;

update public.tiertagger_mods
set version_label = coalesce(version_label, file_name),
    id = coalesce(id, gen_random_uuid());

alter table public.tiertagger_mods
  alter column id set not null,
  alter column version_label set not null;

do $$
begin
  if exists (
    select 1
    from pg_constraint
    where conrelid = 'public.tiertagger_mods'::regclass
      and conname = 'tiertagger_mods_pkey'
  ) then
    alter table public.tiertagger_mods drop constraint tiertagger_mods_pkey;
  end if;
end $$;

alter table public.tiertagger_mods
  add constraint tiertagger_mods_pkey primary key (id);

create unique index if not exists idx_tiertagger_mods_mode_version
  on public.tiertagger_mods (mode_kind, version_label);

create index if not exists idx_tiertagger_mods_mode_updated
  on public.tiertagger_mods (mode_kind, updated_at desc);

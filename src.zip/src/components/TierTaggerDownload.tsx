import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { PvpMode } from "@/hooks/usePvpMode";

interface ModRow {
  file_path: string;
  file_name: string;
  size_bytes: number;
}

function formatSize(b: number) {
  if (!b) return "";
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}

export function TierTaggerDownload({ mode }: { mode: PvpMode }) {
  const [row, setRow] = useState<ModRow | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setRow(null);
    supabase
      .from("tiertagger_mods")
      .select("file_path, file_name, size_bytes")
      .eq("mode_kind", mode)
      .maybeSingle()
      .then(({ data }) => {
        if (!active) return;
        setRow((data as ModRow | null) ?? null);
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [mode]);

  const url = row
    ? supabase.storage.from("tiertagger-mods").getPublicUrl(row.file_path).data.publicUrl
    : null;

  const label = `Download TierTagger Mod`;
  const subtitle = mode === "modern" ? "Modern PvP" : "Classic PvP (1.8.9)";

  if (loading || !row || !url) {
    return (
      <button
        type="button"
        disabled
        className="inline-flex items-center gap-2 rounded-md border border-border bg-card/60 px-3 py-2 text-xs font-bold text-muted-foreground cursor-not-allowed"
        title="No mod uploaded yet"
      >
        <Download className="h-4 w-4" />
        <span className="flex flex-col items-start leading-tight">
          <span>{label}</span>
          <span className="text-[10px] font-normal text-muted-foreground/70">
            {loading ? "Loading…" : `${subtitle} · not available`}
          </span>
        </span>
      </button>
    );
  }

  return (
    <a
      href={url}
      download={row.file_name}
      className="group inline-flex items-center gap-2 rounded-md border border-primary/50 bg-primary/15 px-3 py-2 text-xs font-bold text-foreground shadow-[0_0_18px_-6px_var(--primary)] hover:bg-primary/25 transition-colors"
    >
      <Download className="h-4 w-4 text-primary transition-transform group-hover:translate-y-0.5" />
      <span className="flex flex-col items-start leading-tight">
        <span>{label}</span>
        <span className="text-[10px] font-normal text-muted-foreground">
          {subtitle} · {row.file_name}
          {row.size_bytes ? ` · ${formatSize(row.size_bytes)}` : ""}
        </span>
      </span>
    </a>
  );
}

import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { PvpMode } from "@/hooks/usePvpMode";

interface ModRow {
  id: string;
  file_path: string;
  file_name: string;
  size_bytes: number;
  version_label: string;
}

function formatSize(bytes: number) {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export function TierTaggerDownload({ mode }: { mode: PvpMode }) {
  const [rows, setRows] = useState<ModRow[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setRows([]);
    setSelectedId("");

    supabase
      .from("tiertagger_mods")
      .select("id, file_path, file_name, size_bytes, version_label")
      .eq("mode_kind", mode)
      .order("updated_at", { ascending: false })
      .then(({ data }) => {
        if (!active) return;
        const nextRows = (data as ModRow[] | null) ?? [];
        setRows(nextRows);
        setSelectedId(nextRows[0]?.id ?? "");
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [mode]);

  const row = rows.find((r) => r.id === selectedId) ?? rows[0] ?? null;
  const url = row
    ? supabase.storage.from("tiertagger-mods").getPublicUrl(row.file_path).data.publicUrl
    : null;

  const label = "Download TierTagger Mod";
  const subtitle = mode === "modern" ? "Modern PvP" : "Classic PvP (1.8.9)";

  if (loading || !row || !url) {
    return (
      <button
        type="button"
        disabled
        className="inline-flex items-center gap-2 rounded-md border border-border bg-card/60 px-3 py-2 text-xs font-bold text-muted-foreground cursor-not-allowed"
        title="No mod uploaded yet"
      >
        <Download className="h-4 w-4" />
        <span className="flex flex-col items-start leading-tight">
          <span>{label}</span>
          <span className="text-[10px] font-normal text-muted-foreground/70">
            {loading ? "Loading..." : `${subtitle} - not available`}
          </span>
        </span>
      </button>
    );
  }

  if (rows.length > 1) {
    return (
      <div className="inline-flex items-stretch overflow-hidden rounded-md border border-primary/50 bg-primary/15 text-xs font-bold text-foreground shadow-[0_0_18px_-6px_var(--primary)]">
        <select
          value={row.id}
          onChange={(e) => setSelectedId(e.target.value)}
          className="max-w-[180px] bg-card/95 px-3 py-2 text-xs font-bold outline-none hover:bg-card"
          aria-label="Select TierTagger version"
        >
          {rows.map((r) => (
            <option key={r.id} value={r.id}>
              {r.version_label}
            </option>
          ))}
        </select>
        <a
          href={url}
          download={row.file_name}
          className="group inline-flex items-center gap-2 border-l border-primary/40 px-3 py-2 hover:bg-primary/25 transition-colors"
        >
          <Download className="h-4 w-4 text-primary transition-transform group-hover:translate-y-0.5" />
          <span className="flex flex-col items-start leading-tight">
            <span>{label}</span>
            <span className="text-[10px] font-normal text-muted-foreground">
              {subtitle} - {formatSize(row.size_bytes)}
            </span>
          </span>
        </a>
      </div>
    );
  }

  return (
    <a
      href={url}
      download={row.file_name}
      className="group inline-flex items-center gap-2 rounded-md border border-primary/50 bg-primary/15 px-3 py-2 text-xs font-bold text-foreground shadow-[0_0_18px_-6px_var(--primary)] hover:bg-primary/25 transition-colors"
    >
      <Download className="h-4 w-4 text-primary transition-transform group-hover:translate-y-0.5" />
      <span className="flex flex-col items-start leading-tight">
        <span>{label}</span>
        <span className="text-[10px] font-normal text-muted-foreground">
          {subtitle} - {row.file_name}
          {row.size_bytes ? ` - ${formatSize(row.size_bytes)}` : ""}
        </span>
      </span>
    </a>
  );
}

import { supabase } from "@/integrations/supabase/client";
import { fetchAllRows } from "@/lib/fetch-all";
import { TIER_POINTS, type GamemodeSlug, type Tier } from "@/lib/gamemodes";

export interface RawEntry {
  id: string;
  player_name: string;
  gamemode: GamemodeSlug;
  tier: Tier;
  position: number;
  region: string;
  points: number;
  title: string | null;
  glow: boolean;
  mode_kind: "classic" | "modern";
  is_manual?: boolean;
}

export interface ModeData {
  entries: RawEntry[];
  totals: Map<string, number>;
  fetchedAt: number;
}

type FetchExternalFn = (args: {
  data: { mode: "classic" | "modern" };
}) => Promise<{ entries: unknown[] }>;

const cache: Partial<Record<"classic" | "modern", ModeData>> = {};
const inflight: Partial<Record<"classic" | "modern", Promise<ModeData>>> = {};
const TTL_MS = 60 * 60_000; // 1 hour, matches server-side external cache

export function getCachedTiers(mode: "classic" | "modern"): ModeData | null {
  const c = cache[mode];
  return c ?? null;
}

export function loadTiers(
  mode: "classic" | "modern",
  fetchExternalFn: FetchExternalFn,
  { force = false }: { force?: boolean } = {},
): Promise<ModeData> {
  const existing = cache[mode];
  if (!force && existing && Date.now() - existing.fetchedAt < TTL_MS) {
    return Promise.resolve(existing);
  }
  if (inflight[mode]) return inflight[mode]!;

  const p = (async (): Promise<ModeData> => {
    const { data: manualData, error: manualErr } = await fetchAllRows<RawEntry>(
      (from, to) =>
        supabase
          .from("tier_entries")
          .select(
            "id, player_name, gamemode, tier, position, region, points, title, glow, mode_kind, is_manual",
          )
          .eq("mode_kind", mode)
          .range(from, to),
    );
    if (manualErr) throw new Error(manualErr.message);

    let externalData: RawEntry[] = [];
    try {
      const live = await fetchExternalFn({ data: { mode } });
      externalData = (live.entries as Array<Omit<RawEntry, "id" | "title">>).map((e) => ({
        ...e,
        id: `external:${mode}:${e.gamemode}:${e.player_name.toLowerCase()}`,
        title: null,
      }));
    } catch {
      /* external unavailable */
    }

    const manualKeys = new Set(
      (manualData ?? []).map((e) => `${e.player_name.toLowerCase()}|${e.gamemode}`),
    );
    const all: RawEntry[] = [
      ...(manualData ?? []),
      ...externalData.filter(
        (e) => !manualKeys.has(`${e.player_name.toLowerCase()}|${e.gamemode}`),
      ),
    ];

    const totals = new Map<string, number>();
    for (const e of all) {
      const k = e.player_name.toLowerCase();
      totals.set(k, (totals.get(k) ?? 0) + (e.points || TIER_POINTS[e.tier]));
    }

    const data: ModeData = { entries: all, totals, fetchedAt: Date.now() };
    cache[mode] = data;
    return data;
  })();

  inflight[mode] = p;
  p.finally(() => {
    delete inflight[mode];
  });
  return p;
}

export function invalidateTiers(mode?: "classic" | "modern") {
  if (mode) {
    delete cache[mode];
  } else {
    delete cache.classic;
    delete cache.modern;
  }
}

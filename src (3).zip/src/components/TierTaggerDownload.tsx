import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { PvpMode } from "@/hooks/usePvpMode";

interface ModFile {
  path: string;
  name: string;
  versionLabel: string;
  sizeBytes: number;
}

function formatSize(bytes: number) {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function versionLabelFromStorageName(name: string) {
  const withoutPrefix = name.replace(/^\d+-[0-9a-f-]+-/i, "");
  return withoutPrefix.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ").trim() || withoutPrefix;
}

export function TierTaggerDownload({ mode }: { mode: PvpMode }) {
  const [files, setFiles] = useState<ModFile[]>([]);
  const [selectedPath, setSelectedPath] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setFiles([]);
    setSelectedPath("");

    supabase.storage
      .from("tiertagger-mods")
      .list(mode, {
        limit: 100,
        sortBy: { column: "updated_at", order: "desc" },
      })
      .then(({ data }) => {
        if (!active) return;
        const nextFiles =
          data
            ?.filter((file) => file.name && file.name !== ".emptyFolderPlaceholder")
            .map((file) => ({
              path: `${mode}/${file.name}`,
              name: file.name.replace(/^\d+-[0-9a-f-]+-/i, ""),
              versionLabel: versionLabelFromStorageName(file.name),
              sizeBytes: Number(file.metadata?.size ?? 0),
            })) ?? [];
        setFiles(nextFiles);
        setSelectedPath(nextFiles[0]?.path ?? "");
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [mode]);

  const file = files.find((f) => f.path === selectedPath) ?? files[0] ?? null;
  const url = file
    ? supabase.storage.from("tiertagger-mods").getPublicUrl(file.path).data.publicUrl
    : null;

  const label = "Download TierTagger Mod";
  const subtitle = mode === "modern" ? "Modern PvP" : "Classic PvP (1.8.9)";

  if (loading || !file || !url) {
    return (
      <button
        type="button"
        disabled
        className="inline-flex items-center gap-2 rounded-md border border-border bg-card/60 px-3 py-2 text-xs font-bold text-muted-foreground cursor-not-allowed"
        title="No mod uploaded yet"
      >
        <Download className="h-4 w-4" />
        <span className="flex flex-col items-start leading-tight">
          <span>{label}</span>
          <span className="text-[10px] font-normal text-muted-foreground/70">
            {loading ? "Loading..." : `${subtitle} - not available`}
          </span>
        </span>
      </button>
    );
  }

  if (files.length > 1) {
    return (
      <div className="inline-flex items-stretch overflow-hidden rounded-md border border-primary/50 bg-primary/15 text-xs font-bold text-foreground shadow-[0_0_18px_-6px_var(--primary)]">
        <select
          value={file.path}
          onChange={(e) => setSelectedPath(e.target.value)}
          className="max-w-[180px] bg-card/95 px-3 py-2 text-xs font-bold outline-none hover:bg-card"
          aria-label="Select TierTagger version"
        >
          {files.map((f) => (
            <option key={f.path} value={f.path}>
              {f.versionLabel}
            </option>
          ))}
        </select>
        <a
          href={url}
          download={file.name}
          className="group inline-flex items-center gap-2 border-l border-primary/40 px-3 py-2 hover:bg-primary/25 transition-colors"
        >
          <Download className="h-4 w-4 text-primary transition-transform group-hover:translate-y-0.5" />
          <span className="flex flex-col items-start leading-tight">
            <span>{label}</span>
            <span className="text-[10px] font-normal text-muted-foreground">
              {subtitle} - {formatSize(file.sizeBytes)}
            </span>
          </span>
        </a>
      </div>
    );
  }

  return (
    <a
      href={url}
      download={file.name}
      className="group inline-flex items-center gap-2 rounded-md border border-primary/50 bg-primary/15 px-3 py-2 text-xs font-bold text-foreground shadow-[0_0_18px_-6px_var(--primary)] hover:bg-primary/25 transition-colors"
    >
      <Download className="h-4 w-4 text-primary transition-transform group-hover:translate-y-0.5" />
      <span className="flex flex-col items-start leading-tight">
        <span>{label}</span>
        <span className="text-[10px] font-normal text-muted-foreground">
          {subtitle} - {file.name}
          {file.sizeBytes ? ` - ${formatSize(file.sizeBytes)}` : ""}
        </span>
      </span>
    </a>
  );
}

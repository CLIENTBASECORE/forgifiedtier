import { useEffect, useRef, useState } from "react";
import { ChevronDown, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { PvpMode } from "@/hooks/usePvpMode";

interface ModFile {
  path: string;
  name: string;
  versionLabel: string;
  sizeBytes: number;
}

function formatSize(bytes: number) {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function versionLabelFromStorageName(name: string) {
  const withoutPrefix = name.replace(/^\d+-[0-9a-f-]+-/i, "");
  const [storedLabel] = withoutPrefix.split("--");
  const label = storedLabel.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ").trim() || withoutPrefix;
  const words = label.split(/\s+/);
  const half = words.length / 2;
  if (Number.isInteger(half) && words.slice(0, half).join(" ") === words.slice(half).join(" ")) {
    return words.slice(0, half).join(" ");
  }
  return label;
}

export function TierTaggerDownload({ mode }: { mode: PvpMode }) {
  const [files, setFiles] = useState<ModFile[]>([]);
  const [selectedPath, setSelectedPath] = useState("");
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setFiles([]);
    setSelectedPath("");

    supabase.storage
      .from("tiertagger-mods")
      .list(mode, {
        limit: 100,
        sortBy: { column: "updated_at", order: "desc" },
      })
      .then(({ data }) => {
        if (!active) return;
        const nextFiles =
          data
            ?.filter((file) => file.name && file.name !== ".emptyFolderPlaceholder")
            .map((file) => ({
              path: `${mode}/${file.name}`,
              name: file.name.replace(/^\d+-[0-9a-f-]+-/i, ""),
              versionLabel: versionLabelFromStorageName(file.name),
              sizeBytes: Number(file.metadata?.size ?? 0),
            })) ?? [];
        setFiles(nextFiles);
        setSelectedPath(nextFiles[0]?.path ?? "");
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [mode]);

  useEffect(() => {
    const onPointerDown = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) setOpen(false);
    };
    window.addEventListener("pointerdown", onPointerDown);
    return () => window.removeEventListener("pointerdown", onPointerDown);
  }, []);

  const file = files.find((f) => f.path === selectedPath) ?? files[0] ?? null;
  const url = file
    ? supabase.storage.from("tiertagger-mods").getPublicUrl(file.path).data.publicUrl
    : null;

  const label = "Download TierTagger Mod";
  const subtitle = mode === "modern" ? "Modern PvP" : "Classic PvP (1.8.9)";

  if (loading || !file || !url) {
    return (
      <button
        type="button"
        disabled
        className="inline-flex items-center gap-2 rounded-md border border-border bg-card/60 px-3 py-2 text-xs font-bold text-muted-foreground cursor-not-allowed"
        title="No mod uploaded yet"
      >
        <Download className="h-4 w-4" />
        <span className="flex flex-col items-start leading-tight">
          <span>{label}</span>
          <span className="text-[10px] font-normal text-muted-foreground/70">
            {loading ? "Loading..." : `${subtitle} - not available`}
          </span>
        </span>
      </button>
    );
  }

  if (files.length > 1) {
    return (
      <div
        ref={menuRef}
        className="relative inline-flex items-stretch overflow-visible rounded-md border border-primary/35 bg-card/80 text-[11px] font-bold text-foreground shadow-[0_0_10px_-7px_var(--primary)]"
      >
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="inline-flex max-w-[150px] items-center gap-2 px-2.5 py-1.5 text-left transition-colors hover:bg-primary/10"
          aria-haspopup="listbox"
          aria-expanded={open}
        >
          <span className="truncate">{file.versionLabel}</span>
          <ChevronDown className={`h-3 w-3 shrink-0 text-primary transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
        {open && (
          <div
            role="listbox"
            className="compact-version-menu absolute left-0 top-[calc(100%+4px)] z-50 max-h-44 w-56 overflow-y-auto rounded-md border border-border bg-card/95 p-1 shadow-xl backdrop-blur"
          >
            {files.map((f) => (
              <button
                key={f.path}
                type="button"
                role="option"
                aria-selected={f.path === file.path}
                onClick={() => {
                  setSelectedPath(f.path);
                  setOpen(false);
                }}
                className={`block w-full truncate rounded px-2 py-1.5 text-left text-[11px] transition-colors ${
                  f.path === file.path
                    ? "bg-primary/18 text-foreground"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground"
                }`}
              >
                {f.versionLabel}
              </button>
            ))}
          </div>
        )}
        <a
          href={url}
          download={file.name}
          className="group inline-flex items-center gap-1.5 border-l border-primary/25 px-2.5 py-1.5 hover:bg-primary/10 transition-colors"
        >
          <Download className="h-3.5 w-3.5 text-primary transition-transform group-hover:translate-y-0.5" />
          <span className="flex flex-col items-start leading-tight">
            <span>Download</span>
            <span className="text-[10px] font-normal text-muted-foreground">
              {subtitle} - {formatSize(file.sizeBytes)}
            </span>
          </span>
        </a>
      </div>
    );
  }

  return (
    <a
      href={url}
      download={file.name}
      className="group inline-flex items-center gap-1.5 rounded-md border border-primary/35 bg-card/80 px-2.5 py-1.5 text-[11px] font-bold text-foreground shadow-[0_0_10px_-7px_var(--primary)] hover:bg-primary/10 transition-colors"
    >
      <Download className="h-3.5 w-3.5 text-primary transition-transform group-hover:translate-y-0.5" />
      <span className="flex flex-col items-start leading-tight">
        <span>{label}</span>
        <span className="text-[10px] font-normal text-muted-foreground">
          {subtitle} - {file.name}
          {file.sizeBytes ? ` - ${formatSize(file.sizeBytes)}` : ""}
        </span>
      </span>
    </a>
  );
}

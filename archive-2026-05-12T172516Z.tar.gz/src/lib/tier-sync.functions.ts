import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  MODERN_GAMEMODES,
  TIER_POINTS,
  type GamemodeSlug,
  type Tier,
} from "@/lib/gamemodes";

// ---------- helpers ----------

function tierFromMcTiersIndex(tierIdx: number, sub: number): Tier | null {
  if (tierIdx < 0 || tierIdx > 4) return null;
  const prefix = sub === 0 ? "HT" : "LT";
  return `${prefix}${tierIdx + 1}` as Tier;
}

function dashUuid(raw: string): string {
  if (raw.length !== 32) return raw;
  return `${raw.slice(0, 8)}-${raw.slice(8, 12)}-${raw.slice(12, 16)}-${raw.slice(16, 20)}-${raw.slice(20)}`;
}

async function resolveUsername(uuid: string): Promise<string | null> {
  try {
    const res = await fetch(`https://playerdb.co/api/player/minecraft/${dashUuid(uuid)}`, {
      headers: { "User-Agent": "ForgifiedTiers/1.0 (+live)" },
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { data?: { player?: { username?: string } } };
    return json?.data?.player?.username ?? null;
  } catch {
    return null;
  }
}

async function resolveAll(uuids: string[]): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  const batchSize = 20;
  for (let i = 0; i < uuids.length; i += batchSize) {
    const batch = uuids.slice(i, i + batchSize);
    const results = await Promise.all(batch.map((u) => resolveUsername(u).then((n) => [u, n] as const)));
    for (const [u, n] of results) if (n) out.set(u, n);
  }
  return out;
}

function mctiersModeSlug(slug: string): string {
  return slug === "nethop" ? "nethpot" : slug;
}

// ---------- live fetch (no DB writes) ----------

export interface LiveTierEntry {
  player_name: string;
  gamemode: GamemodeSlug;
  tier: Tier;
  region: string;
  points: number;
  position: number;
  glow: false;
  mode_kind: "modern" | "classic";
  is_manual: false;
}

interface CacheEntry {
  at: number;
  data: LiveTierEntry[];
}
const CACHE_TTL_MS = 60 * 60 * 1000; // refresh externals once per hour
type CacheKey = "modern:mctiers" | "modern:pvptiers" | "modern:off" | "classic";
const liveCache = new Map<CacheKey, CacheEntry>();

export type ModernSource = "mctiers" | "pvptiers" | "off";

async function readModernSource(): Promise<ModernSource> {
  try {
    const { data } = await supabaseAdmin
      .from("app_settings")
      .select("value")
      .eq("key", "modern_source")
      .maybeSingle();
    const v = (data?.value as string | undefined) ?? "mctiers";
    return v === "pvptiers" ? "pvptiers" : v === "off" ? "off" : "mctiers";
  } catch {
    return "mctiers";
  }
}

async function fetchModernLivePvptiers(): Promise<LiveTierEntry[]> {
  // pvptiers slug -> our app gamemode slug
  const PVPTIERS_MAP: Array<{ api: string; gamemode: GamemodeSlug }> = [
    { api: "sword", gamemode: "sword" },
    { api: "axe", gamemode: "axe" },
    { api: "smp", gamemode: "smp" },
    { api: "mace", gamemode: "mace" },
    { api: "pot", gamemode: "pot" },
    { api: "uhc", gamemode: "uhc" },
    { api: "crystal", gamemode: "vanilla" },
    { api: "neth_pot", gamemode: "nethop" },
  ];
  type Entry = { name: string; region: string; tier: number; pos: number; retired?: boolean };
  const out: LiveTierEntry[] = [];
  await Promise.all(
    PVPTIERS_MAP.map(async ({ api, gamemode }) => {
      try {
        // pvptiers caps each tier bucket at 50 entries per response — paginate
        // with `from=` until no new players come back. Cap for safety.
        const seen = new Set<string>();
        const all: Entry[] = [];
        let from = 0;
        const MAX_FROM = 20000;
        while (from <= MAX_FROM) {
          const res = await fetch(
            `https://pvptiers.com/api/tier/${api}?count=1000&from=${from}`,
            { headers: { "User-Agent": "ForgifiedTiers/1.0 (+live)" } },
          );
          if (!res.ok) break;
          const json = (await res.json()) as Entry[][];
          let added = 0;
          for (const bucket of json ?? []) {
            for (const p of bucket) {
              const key = `${p.name.toLowerCase()}|${p.tier}|${p.pos}`;
              if (seen.has(key)) continue;
              seen.add(key);
              all.push(p);
              added++;
            }
          }
          if (added === 0) break;
          from += 50;
        }
        let position = 0;
        for (const p of all) {
          const tier = tierFromMcTiersIndex(p.tier - 1, p.pos);
          if (!tier) continue;
          out.push({
            player_name: p.name,
            gamemode,
            tier,
            region: p.region || "NA",
            points: TIER_POINTS[tier] ?? 0,
            position: position++,
            glow: false,
            mode_kind: "modern",
            is_manual: false,
          });
        }
      } catch {
        /* ignore single-gamemode failures */
      }
    })
  );
  return out;
}

async function fetchModernLive(): Promise<LiveTierEntry[]> {
  const out: LiveTierEntry[] = [];
  type Bucket = Record<string, Array<{ uuid: string; name?: string; region?: string; pos: number }>>;
  await Promise.all(
    MODERN_GAMEMODES.map(async (g) => {
      try {
        // Fetch BOTH active and retired so the overall list includes everyone.
        const [activeRes, retiredRes] = await Promise.all([
          fetch(`https://mctiers.com/api/v2/mode/${mctiersModeSlug(g.slug)}?count=100000`, {
            headers: { "User-Agent": "ForgifiedTiers/1.0 (+live)" },
          }),
          fetch(`https://mctiers.com/api/v2/mode/${mctiersModeSlug(g.slug)}/retired?count=100000`, {
            headers: { "User-Agent": "ForgifiedTiers/1.0 (+live)" },
          }),
        ]);
        const sources: Bucket[] = [];
        if (activeRes.ok) sources.push((await activeRes.json()) as Bucket);
        if (retiredRes.ok) sources.push((await retiredRes.json()) as Bucket);
        let position = 0;
        const seen = new Set<string>();
        const missingName = new Set<string>();
        for (const json of sources) {
          for (const tierKey of ["1", "2", "3", "4", "5"]) {
            const bucket = json[tierKey];
            if (!Array.isArray(bucket)) continue;
            for (const p of bucket) {
              if (!p.name && p.uuid) missingName.add(p.uuid);
            }
          }
        }
        const resolvedNames = await resolveAll([...missingName]);
        for (const json of sources) {
          for (const tierKey of ["1", "2", "3", "4", "5"]) {
            const bucket = json[tierKey];
            if (!Array.isArray(bucket)) continue;
            const tierIdx = parseInt(tierKey, 10) - 1;
            for (const p of bucket) {
              const tier = tierFromMcTiersIndex(tierIdx, p.pos);
              if (!tier) continue;
              const playerName = p.name || resolvedNames.get(p.uuid);
              if (!playerName) continue;
              const key = `${p.uuid || playerName.toLowerCase()}::${g.slug}`;
              if (seen.has(key)) continue;
              seen.add(key);
              out.push({
                player_name: playerName,
                gamemode: g.slug as GamemodeSlug,
                tier,
                region: p.region || "NA",
                points: TIER_POINTS[tier] ?? 0,
                position: position++,
                glow: false,
                mode_kind: "modern",
                is_manual: false,
              });
            }
          }
        }
      } catch {
        /* ignore single-gamemode failures */
      }
    })
  );
  return out;
}

// Map tiertests.com tier strings (single S, F) to our schema (S+/F+)
const CLASSIC_TIER_MAP: Record<string, Tier> = {
  "S": "S+", "S+": "S+", "S-": "S-",
  "A+": "A+", "A-": "A-",
  "B+": "B+", "B-": "B-",
  "C+": "C+", "C-": "C-",
  "D+": "D+", "D-": "D-",
  "F": "F+", "F+": "F+", "F-": "F-",
};

// Classic gamemodes available on tiertests.com /leaderboards/{slug}
const CLASSIC_SCRAPE: Array<{ slug: GamemodeSlug; path: string }> = [
  { slug: "boxing", path: "boxing" },
  { slug: "bedfight", path: "bedfight" },
  { slug: "fireballfight", path: "fireballfight" },
  { slug: "sumo", path: "sumo" },
  { slug: "nodebuff", path: "nodebuff" },
  { slug: "uhc", path: "uhc" },
];

function parseTiertestsMarkdown(md: string): Array<{ name: string; region: string; tier: Tier; rank: number }> {
  // Each ranked entry looks like:
  //   - 1
  //
  //   ![NAME avatar](...)
  //   NAME
  //   (optional badge image)
  //   REGION (optional)
  //   M/D/YYYY
  //   TIER
  const re = /-\s+(\d+)\s*\n\s*\n!\[([^\]]+?) avatar\][^\n]*\n[\s\S]*?\n\s*([A-F][+\-]?|S)\s*(?:\n|$)/g;
  // Build a more reliable per-block parser: split by "- N\n" rank delimiters
  const blocks = md.split(/\n(?=- \d+\s*\n)/);
  const out: Array<{ name: string; region: string; tier: Tier; rank: number }> = [];
  for (const blk of blocks) {
    const rankMatch = blk.match(/^-\s+(\d+)\s*\n/);
    if (!rankMatch) continue;
    const rank = parseInt(rankMatch[1], 10);
    const nameMatch = blk.match(/!\[([^\]]+?) avatar\]/);
    if (!nameMatch) continue;
    const name = nameMatch[1].replace(/\\_/g, "_").trim();
    const regionMatch = blk.match(/\n\s*(NA|EU|AS|SA|OCE|AU)\s*\n/);
    const region = regionMatch ? regionMatch[1] : "NA";
    // Tier is the last short token in the block (one of S, A+, A-, B+, ...)
    const tierMatches = [...blk.matchAll(/\n\s*([A-F][+\-]?|S)\s*(?=\n|$)/g)];
    if (tierMatches.length === 0) continue;
    const rawTier = tierMatches[tierMatches.length - 1][1];
    const tier = CLASSIC_TIER_MAP[rawTier];
    if (!tier) continue;
    out.push({ name, region, tier, rank });
  }
  void re;
  return out;
}

async function scrapeClassicGamemode(
  slug: GamemodeSlug,
  path: string,
  apiKey: string
): Promise<LiveTierEntry[]> {
  try {
    const res = await fetch("https://api.firecrawl.dev/v2/scrape", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url: `https://tiertests.com/leaderboards/${path}`,
        formats: ["markdown"],
        onlyMainContent: true,
        waitFor: 4000,
      }),
    });
    if (!res.ok) return [];
    const json = (await res.json()) as { data?: { markdown?: string } };
    const md = json?.data?.markdown ?? "";
    if (!md) return [];
    const parsed = parseTiertestsMarkdown(md);
    return parsed.map((p) => ({
      player_name: p.name,
      gamemode: slug,
      tier: p.tier,
      region: p.region,
      points: TIER_POINTS[p.tier] ?? 0,
      position: p.rank - 1,
      glow: false as const,
      mode_kind: "classic" as const,
      is_manual: false as const,
    }));
  } catch {
    return [];
  }
}

async function fetchClassicLive(): Promise<LiveTierEntry[]> {
  const apiKey = process.env.FIRECRAWL_API_KEY;
  if (!apiKey) return [];
  const results = await Promise.all(
    CLASSIC_SCRAPE.map((g) => scrapeClassicGamemode(g.slug, g.path, apiKey))
  );
  return results.flat();
}

const liveInputSchema = z.object({
  mode: z.enum(["classic", "modern"]),
  force: z.boolean().optional(),
});

export const fetchExternalTiers = createServerFn({ method: "GET" })
  .inputValidator((data) => liveInputSchema.parse(data))
  .handler(async ({ data }): Promise<{ entries: LiveTierEntry[]; cached: boolean }> => {
    const source: ModernSource = data.mode === "modern" ? await readModernSource() : "mctiers";
    const cacheKey: CacheKey = data.mode === "classic" ? "classic" : (`modern:${source}` as CacheKey);
    const cached = liveCache.get(cacheKey);
    if (!data.force && cached && Date.now() - cached.at < CACHE_TTL_MS) {
      return { entries: cached.data, cached: true };
    }
    const entries =
      data.mode === "classic"
        ? await fetchClassicLive()
        : source === "off"
          ? []
        : source === "pvptiers"
          ? await fetchModernLivePvptiers()
          : await fetchModernLive();
    liveCache.set(cacheKey, { at: Date.now(), data: entries });
    return { entries, cached: false };
  });

export const refreshExternalTiers = createServerFn({ method: "POST" })
  .handler(async (): Promise<{ ok: true; modern: number; classic: number }> => {
    const modernSource = await readModernSource();
    const [modernEntries, classicEntries] = await Promise.all([
      modernSource === "off"
        ? Promise.resolve([])
        : modernSource === "pvptiers"
          ? fetchModernLivePvptiers()
          : fetchModernLive(),
      fetchClassicLive(),
    ]);
    liveCache.set(`modern:${modernSource}` as CacheKey, { at: Date.now(), data: modernEntries });
    liveCache.set("classic", { at: Date.now(), data: classicEntries });
    return { ok: true, modern: modernEntries.length, classic: classicEntries.length };
  });


// ---------- apply / remove external tiers as real DB rows ----------

export const applyExternalTiers = createServerFn({ method: "POST" })
  .inputValidator((data) => liveInputSchema.parse(data))
  .handler(async ({ data }): Promise<{ ok: boolean; inserted: number; skipped: number; fetched: number; errors: string[] }> => {
    let live: LiveTierEntry[];
    if (data.mode === "classic") {
      if (!process.env.FIRECRAWL_API_KEY) {
        return {
          ok: false,
          inserted: 0,
          skipped: 0,
          fetched: 0,
          errors: ["Classic external source requires the Firecrawl connector. Connect Firecrawl, or use Modern (mctiers/pvptiers) which works without it."],
        };
      }
      live = await fetchClassicLive();
    } else {
      const source = await readModernSource();
      live = source === "off"
        ? []
        : source === "pvptiers"
          ? await fetchModernLivePvptiers()
          : await fetchModernLive();
    }

    // Load existing rows for this mode so we can skip duplicates and never
    // overwrite manual edits.
    const { data: existingRows, error: exErr } = await supabaseAdmin
      .from("tier_entries")
      .select("player_name, gamemode")
      .eq("mode_kind", data.mode);
    if (exErr) return { ok: false, inserted: 0, skipped: 0, fetched: live.length, errors: [exErr.message] };
    const taken = new Set((existingRows ?? []).map((r) => `${r.player_name.toLowerCase()}::${r.gamemode}`));

    // Deduplicate within the live batch too (same player+gamemode appearing twice).
    const toInsert: LiveTierEntry[] = [];
    let skipped = 0;
    for (const e of live) {
      const k = `${e.player_name.toLowerCase()}::${e.gamemode}`;
      if (taken.has(k)) { skipped++; continue; }
      taken.add(k);
      toInsert.push(e);
    }

    // Bulk insert in chunks so every player actually lands in the database.
    let inserted = 0;
    const errors: string[] = [];
    const CHUNK = 500;
    for (let i = 0; i < toInsert.length; i += CHUNK) {
      const chunk = toInsert.slice(i, i + CHUNK).map((e) => ({
        player_name: e.player_name,
        gamemode: e.gamemode,
        tier: e.tier,
        region: e.region,
        points: e.points,
        position: e.position,
        glow: false,
        mode_kind: e.mode_kind,
        is_manual: false,
      }));
      const { error, count } = await supabaseAdmin
        .from("tier_entries")
        .insert(chunk, { count: "exact" });
      if (error) {
        errors.push(error.message);
        // Fall back to per-row inserts so a single bad row doesn't drop the whole chunk.
        for (const row of chunk) {
          const { error: rErr } = await supabaseAdmin.from("tier_entries").insert(row);
          if (rErr) errors.push(rErr.message);
          else inserted++;
        }
      } else {
        inserted += count ?? chunk.length;
      }
    }
    return { ok: errors.length === 0, inserted, skipped, fetched: live.length, errors: errors.slice(0, 5) };
  });

export const removeExternalTiers = createServerFn({ method: "POST" })
  .inputValidator((data) => liveInputSchema.parse(data))
  .handler(async ({ data }): Promise<{ ok: boolean; deleted: number; errors: string[] }> => {
    const { data: rows, error: delErr, count } = await supabaseAdmin
      .from("tier_entries")
      .delete({ count: "exact" })
      .eq("mode_kind", data.mode)
      .eq("is_manual", false)
      .select("id");
    if (delErr) return { ok: false, deleted: 0, errors: [delErr.message] };
    return { ok: true, deleted: count ?? rows?.length ?? 0, errors: [] };
  });

// ---------- bulk shift (manual entries only, since DB is now manual-only) ----------

const shiftSchema = z.object({
  mode: z.enum(["classic", "modern"]),
  gamemode: z.string(),
  delta: z.union([z.literal(1), z.literal(-1)]),
});

export const bulkShiftTier = createServerFn({ method: "POST" })
  .inputValidator((data) => shiftSchema.parse(data))
  .handler(async ({ data }) => {
    const tiersArr =
      data.mode === "modern"
        ? (["HT1", "LT1", "HT2", "LT2", "HT3", "LT3", "HT4", "LT4", "HT5", "LT5"] as Tier[])
        : ([
            "S+", "S-", "A+", "A-", "B+", "B-",
            "C+", "C-", "D+", "D-", "F+", "F-",
          ] as Tier[]);

    const { data: rows, error } = await supabaseAdmin
      .from("tier_entries")
      .select("id, tier")
      .eq("mode_kind", data.mode)
      .eq("gamemode", data.gamemode as GamemodeSlug);
    if (error) return { ok: false, updated: 0, error: error.message };

    let updated = 0;
    const errors: string[] = [];
    const step = data.delta === 1 ? -1 : 1;

    await Promise.all(
      (rows ?? []).map(async (r) => {
        const idx = tiersArr.indexOf(r.tier as Tier);
        if (idx < 0) return;
        const newIdx = Math.min(tiersArr.length - 1, Math.max(0, idx + step));
        if (newIdx === idx) return;
        const newTier = tiersArr[newIdx];
        const { error: uErr } = await supabaseAdmin
          .from("tier_entries")
          .update({ tier: newTier, points: TIER_POINTS[newTier] ?? 0 })
          .eq("id", r.id);
        if (uErr) errors.push(uErr.message);
        else updated++;
      })
    );

    return { ok: errors.length === 0, updated, error: errors[0] ?? null };
  });

// Backwards-compat stub: the old "Sync" button is gone but keep the export
// so any stale import doesn't break the build during the transition.
export const syncExternalTiers = createServerFn({ method: "POST" })
  .inputValidator((data) => liveInputSchema.parse(data))
  .handler(async ({ data }) => ({
    ok: true,
    mode: data.mode,
    fetched: 0,
    inserted: 0,
    skipped_manual: 0,
    errors: [],
    message: "External tiers are now fetched live on every page load — no sync needed.",
  }));

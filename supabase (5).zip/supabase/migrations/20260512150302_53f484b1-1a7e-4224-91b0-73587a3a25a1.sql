-- 1. Add 'tester' to app_role enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'tester';
